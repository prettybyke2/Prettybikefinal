﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;


namespace Prettybike
{
    public partial class Manager_Part : Form
    {
        public Manager_Part()
        {
            InitializeComponent();
        }


        public int increment = 0;


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtbox_CurrentOrder_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbox_amount_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dateTP_Manager_from_ValueChanged(object sender, EventArgs e)
        {

        }

        private void lbl_Manager_Click(object sender, EventArgs e)
        {

        }

        private void btn_newOrder_Click(object sender, EventArgs e)
        {
            increment++;
            Newpage();
            MessageBox.Show(increment.ToString());

        }

        public void Newpage()
        {

            Manager_Part manager_Part = new Manager_Part();
            manager_Part.Show();

            this.Hide();


            



            string connectionString = "database = New_db; server = pat.infolab.ecam.be;port = 63345; user = admin; pwd = prettybyke2";

            MySqlConnection myConnection = new MySqlConnection(connectionString);
            try
            {
                myConnection.Open();
                MessageBox.Show("Connecté");
                String QueryRepres = "SELECT * FROM Representative";
                String QueryCommand = "SELECT* FROM Command";
                String QueryBuilders = "SELECT * FROM Builder";
                String Querycmd_line = "SELECT * FROM cmd_line";
                String QueryBikes = "SELECT * FROM Bikes";


                MySqlCommand myCmd_Client = new MySqlCommand(QueryRepres, myConnection);
                MySqlCommand myCmd_Order = new MySqlCommand(QueryCommand, myConnection);
                MySqlCommand myCmd_Builder = new MySqlCommand(QueryBuilders, myConnection);
                MySqlCommand myCmd_cmd_line = new MySqlCommand(Querycmd_line, myConnection);
                MySqlCommand myCmd_Bikes = new MySqlCommand(QueryBikes, myConnection);




                //Reader Command/Order
                MySqlDataReader myDBReaderOrder = myCmd_Order.ExecuteReader();
                DataTable myDTOrder = new DataTable();
                myDTOrder.Load(myDBReaderOrder);
                string IDClientstring = myDTOrder.Rows[increment]["Representative_id_rps"].ToString();
                int IDClient = Int32.Parse(IDClientstring);
                IDClient = IDClient - 1;
                myDBReaderOrder.Close();
                myDBReaderOrder = null;


                //Reader Client
                MySqlDataReader myDBReaderClient = myCmd_Client.ExecuteReader();
                DataTable myDTClients = new DataTable();
                myDTClients.Load(myDBReaderClient);
                myDBReaderClient.Close();
                myDBReaderClient = null;



                //Reader Builder
                MySqlDataReader myDBReaderBuilder = myCmd_Builder.ExecuteReader();
                DataTable myDTBuilders = new DataTable();
                myDTBuilders.Load(myDBReaderBuilder);
                myDBReaderBuilder.Close();
                myDBReaderBuilder = null;

                //Reader Cmd_line
                MySqlDataReader myDBReadercmd_line = myCmd_cmd_line.ExecuteReader();
                DataTable myDTcmd_line = new DataTable();
                myDTcmd_line.Load(myDBReadercmd_line);
                string IDBikestring = myDTcmd_line.Rows[increment]["Bikes_idBikes"].ToString();
                int IDBike = Int32.Parse(IDBikestring);
                IDBike = IDBike - 1;

                myDBReadercmd_line.Close();
                myDBReadercmd_line = null;

                //MessageBox.Show("test 3");
                //Reader Bikes
                MySqlDataReader myDBReaderBikes = myCmd_Bikes.ExecuteReader();
                DataTable myDTbikes = new DataTable();
                myDTbikes.Load(myDBReaderBikes);


                myDBReaderBikes.Close();
                myDBReaderBikes = null;

                ;
                //MessageBox.Show("test 4");



                //Define inner texts
                manager_Part.lbl_orderdate.Text = myDTOrder.Rows[increment]["date_cmd"].ToString();
                manager_Part.lbl_representative.Text = myDTClients.Rows[IDClient]["Company_Name"].ToString();
                manager_Part.lbl_TotalAmount_Generate.Text = myDTcmd_line.Rows[increment]["qty"].ToString();
                manager_Part.lbl_model.Text = myDTbikes.Rows[IDBike]["Bikes_Model"].ToString();
                manager_Part.lbl_color.Text = myDTbikes.Rows[IDBike]["Bikes_Color"].ToString();
                manager_Part.lbl_size.Text = myDTbikes.Rows[IDBike]["Bikes_Size"].ToString();




                //NOT WORKING PART NEXT
                //reprendre entre ici...

                //DateTime dateFrom = manager_Part.dateTP_Manager_from.Value;

                //MessageBox.Show(dateFrom.GetType().ToString());
                //int IDBuilder = 1;
                //string insertSQL = "INSERT INTO Working_Day(Date, Builder_idBuilder) VALUES (2004-04-22 00:00:00, 1)";
                //MessageBox.Show("Test 1 ");

                //using (MySqlCommand command = new MySqlCommand(insertSQL, myConnection))
                //{


                //    MessageBox.Show("Test 2 ");

                    
                    
                    

                //    // Open the connection and execute the insert command.
                //    try
                //    {
                        
                //        MessageBox.Show("Test 3 ");

                //        int aff = command.ExecuteNonQuery();
                //        MessageBox.Show(aff + " rows were affected.");


                //        MessageBox.Show("Enregistrement réussi ");
                //    }
                //    catch (Exception ex)
                //    {
                //        MessageBox.Show(ex.ToString());
                //    }
                //    //...Et Ici 


                //    // The connection is automatically closed when the
                //    // code exits the using block.
                //}

                // The insertSQL string contains a SQL statement that
                // inserts a new row in the source table.
                //OleDbCommand command = new OleDbCommand(insertSQL);
                // Set the Connection to the new OleDbConnection.

                //string QueryInsertDate = "insert into Working_Day_has_Bikes VALUES ('" + manager_Part.dateTP_Manager_from.Text + "')";
                //// declare oleDbcommand object
                //MessageBox.Show("Test 1 ");

                //OleDbConnection connection = new OleDbConnection(connectionString);
                //MessageBox.Show("Test 2 ");

                //OleDbCommand myInsertCmd = new OleDbCommand(QueryInsertDate, connection);
                //MessageBox.Show("Test 3 ");

                //// execute insert command
                //int nb_row = myInsertCmd.ExecuteNonQuery();
                //if (nb_row == 1)
                //    MessageBox.Show("Enregistrement réussi ");
                //int incr = 0;
                //while (incr < myDT.Rows.Count)
                //{
                //    foreach (DataColumn col in myDT.Columns)
                //    {

                //        MessageBox.Show(myDT.Rows[incr][col].ToString());

                //    }
                //    incr += 1;

                //}



                //                while (mydbreader.read()) // read next line
                //                {
                //                    extract data from record
                //#pragma warning disable cs8600 // conversion de littéral ayant une valeur null ou d'une éventuelle valeur null en type non-nullable.
                //                    string idcmd_line = mydbreader["new_db.idcmd_line"].tostring();
                //#pragma warning restore cs8600 // conversion de littéral ayant une valeur null ou d'une éventuelle valeur null en type non-nullable.
                //                    string qty = mydbreader.getstring(1);
                //                    string idcmd = mydbreader.getstring(2);
                //                    do something with data...
                //                    messagebox.show("connecté de fou");
                //                    messagebox.show(idcmd);
                //                }
            }
            catch
            {
                MessageBox.Show("Non connecté");
            }






        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

}
