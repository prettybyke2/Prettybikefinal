﻿namespace Prettybike
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Connection = new System.Windows.Forms.Label();
            this.btn_login_manager = new System.Windows.Forms.Button();
            this.lbl_Identif = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_login_builder = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_Connection
            // 
            this.lbl_Connection.AutoSize = true;
            this.lbl_Connection.Location = new System.Drawing.Point(433, 151);
            this.lbl_Connection.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Connection.Name = "lbl_Connection";
            this.lbl_Connection.Size = new System.Drawing.Size(0, 15);
            this.lbl_Connection.TabIndex = 14;
            // 
            // btn_login_manager
            // 
            this.btn_login_manager.BackColor = System.Drawing.Color.AliceBlue;
            this.btn_login_manager.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_login_manager.ForeColor = System.Drawing.Color.SteelBlue;
            this.btn_login_manager.Location = new System.Drawing.Point(106, 151);
            this.btn_login_manager.Margin = new System.Windows.Forms.Padding(2);
            this.btn_login_manager.Name = "btn_login_manager";
            this.btn_login_manager.Size = new System.Drawing.Size(78, 28);
            this.btn_login_manager.TabIndex = 9;
            this.btn_login_manager.Text = "LOG IN";
            this.btn_login_manager.UseVisualStyleBackColor = false;
            this.btn_login_manager.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // lbl_Identif
            // 
            this.lbl_Identif.AutoSize = true;
            this.lbl_Identif.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Identif.Location = new System.Drawing.Point(106, 34);
            this.lbl_Identif.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Identif.Name = "lbl_Identif";
            this.lbl_Identif.Size = new System.Drawing.Size(333, 65);
            this.lbl_Identif.TabIndex = 8;
            this.lbl_Identif.Text = "Identification";
            this.lbl_Identif.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_Identif.Click += new System.EventHandler(this.lbl_Identif_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(106, 110);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 21);
            this.label1.TabIndex = 15;
            this.label1.Text = "Manager";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(351, 99);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 21);
            this.label2.TabIndex = 16;
            this.label2.Text = "Builder";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_login_builder
            // 
            this.btn_login_builder.BackColor = System.Drawing.Color.AliceBlue;
            this.btn_login_builder.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_login_builder.ForeColor = System.Drawing.Color.SteelBlue;
            this.btn_login_builder.Location = new System.Drawing.Point(351, 151);
            this.btn_login_builder.Margin = new System.Windows.Forms.Padding(2);
            this.btn_login_builder.Name = "btn_login_builder";
            this.btn_login_builder.Size = new System.Drawing.Size(78, 28);
            this.btn_login_builder.TabIndex = 17;
            this.btn_login_builder.Text = "LOG IN";
            this.btn_login_builder.UseVisualStyleBackColor = false;
            this.btn_login_builder.Click += new System.EventHandler(this.btn_login_builder_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(351, 125);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 23);
            this.comboBox1.TabIndex = 18;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 270);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btn_login_builder);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Connection);
            this.Controls.Add(this.btn_login_manager);
            this.Controls.Add(this.lbl_Identif);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Login";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lbl_Connection;
        private Button btn_login_manager;
        private Label lbl_Identif;
        private Label label1;
        private Label label2;
        private Button btn_login_builder;
        public ComboBox comboBox1;
        private EventHandler comboBox1_SelectedIndexChanged;
    }
}